/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Sun Oct 06 2019                                           */
/*    Description:  Functions Returns                                         */
/*                  This program will use a function to add 10 to integers    */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// addTen functions takes an integer as a parameter. Then, gets the 'finalValue'
// by adding 10 to the 'value' passed in the parameter.
int addTen(int value) {
  int finalValue = value + 10;
  return finalValue;
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Create an int as the original value.
  int originalValue = 0;

  // Use addTen to the original value.
  int secondValue = addTen(originalValue);

  // Print the originalValue and secondValue to the Brain.
  Brain.Screen.print("originalValue = %d", originalValue);
  Brain.Screen.newLine();
  Brain.Screen.print("secondValue = %d", secondValue);

}
