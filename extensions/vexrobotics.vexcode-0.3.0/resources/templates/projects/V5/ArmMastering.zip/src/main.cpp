/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Mar 16 2021                                           */
/*    Description:  Arm Mastering                                             */
/*                                                                            */
/*    This example will help you to find the mastering values                 */
/*    for your Workcell Arm                                                   */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RoboticArm1          RoboticArm    1, 2, 3, 4, 1, 2, 3, 4
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int passCount;

// User defined function
void checkMasteringValue(int min, int max, int value, int joint) {
  // display the value for the joint on the screen
  Brain.Screen.setPenColor(white);
  Brain.Screen.setFillColor(black);
  Brain.Screen.clearLine(joint);
  Brain.Screen.setCursor(Brain.Screen.row(), 1);
  Brain.Screen.setCursor(joint, 1);
  Brain.Screen.print("Joint %d: %d", joint, value);

  Brain.Screen.setCursor(joint, 15);
  if (value < min || max < value) {
    // the value is out of range, so display the valid range
    Brain.Screen.setPenColor(white);
    Brain.Screen.setFillColor(red);
    Brain.Screen.print("FAIL (%d - %d)", min, max);
  }
  else {
    // the value is in range so display that it is a "Pass"
    passCount = passCount + 1;
    Brain.Screen.setPenColor(black);
    Brain.Screen.setFillColor(green);
    Brain.Screen.print("PASS");
  }
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

    Brain.Screen.setFont(mono30);

  RoboticArm1.enterMasteringMode();

  while (true) {
    passCount = 0;
    // check and display the current values for each joint
    checkMasteringValue(1600, 2000, RoboticArm1.getJointValue(1), 1);
    checkMasteringValue(1900, 2400, RoboticArm1.getJointValue(2), 2);
    checkMasteringValue(1700, 2100, RoboticArm1.getJointValue(3), 3);
    checkMasteringValue(200, 650, RoboticArm1.getJointValue(4), 4);

    // if all the joints are in the acceptable range...
    if (passCount == 4) {
      // break out of the loop
      break;
    }

    // wait 0.2 seconds or 200ms before checking and updating the display again
    wait(0.2, seconds);
  }

  // the values are in range. so lock the values on the screen and display that
  // the values have been found
  Brain.Screen.setFillColor(blue);
  Brain.Screen.setPenColor(white);
  Brain.Screen.setCursor(5, 1);
  Brain.Screen.print("--------------------------------");
  Brain.Screen.setCursor(6, 8);
  Brain.Screen.print("Mastering Complete");
  Brain.Screen.setCursor(7, 3);
  Brain.Screen.print("Record the Above Joint Values");
  Brain.Screen.setCursor(8, 3);
  Brain.Screen.print("and Remove the Mastering Jig");
  return 0;
}
