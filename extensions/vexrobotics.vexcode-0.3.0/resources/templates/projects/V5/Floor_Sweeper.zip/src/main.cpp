/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Floor Sweeper                                             */
/*                                                                            */
/*    This program will repeat inside of a forever loop, where it checks      */
/*    if the bumper is being pressed. If the bumper is being pressed,         */
/*    the robot will drive forward until this changes. Once the bumper is     */
/*    pressed, the robot will stop driving and turn right X degrees. X        */
/*    being 90 + a randomly generated number between 0 and 90. Then the       */
/*    program will loop and repeat.                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10, D
// BumperB              bumper        B
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// The pickRandom function returns a random integer between the min and max
// values passed as parameters.
int pickRandom(int min, int max) {
  return min + rand() / (RAND_MAX / (max - min + 1));
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Intialize the random number generator.
  srand(randomSeed);

  while (true) {
    while (!BumperB.pressing()) {
      Drivetrain.drive(forward);
      wait(5, msec);
    }
    Drivetrain.stop();
    Drivetrain.turnFor((90 + pickRandom(0, 90)), degrees);
    wait(5, msec);
  }

}
