/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Mar 30 2021                                           */
/*    Description:  Digital In Sensing                                        */
/*                  This program will use a Digital In device                 */
/*                  to read input signals from another device                 */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10           
// DigitalInA           digital_in    A               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  while (true) {
    // Clear the screen and set the cursor to the top left corner on each loop
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1, 1);

    // The Digital In Sensing command returns True/High when the V5 Brain receives a high signal
    // The Digital In Sensing command returns Low/False when the V5 Brain receives a low signal
    if (DigitalInA.value()) {
      Brain.Screen.print("Input - High");
    }
    else {
      Brain.Screen.print("Input - Low");
    }
    
    // A brief delay to allow text to be printed without distortion or tearing
    wait(20, msec);
  }

}
