/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Wed Sep 25 2019                                           */
/*    Description:  Repeating Actions                                         */
/*                                                                            */
/*    This program drives a robot in a 12 x 12 square by repeating            */
/*    the drive forward and turn commands 4 times.                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10, D        
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // drives forward and turns 90 degrees for 4 iterations
  repeat(4) {
    Drivetrain.driveFor(12, inches);
    Drivetrain.turnFor(90, degrees);
    wait(5, msec);
  }
}