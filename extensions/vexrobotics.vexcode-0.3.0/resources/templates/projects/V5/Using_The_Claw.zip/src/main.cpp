/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Wed Sep 25 2019                                           */
/*    Description:  Using the Claw (degrees)                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftMotor            motor         1
// RightMotor           motor         10
// ClawMotor            motor         3
// ArmMotor             motor         8
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Take the current position of the Claw as zero
  ClawMotor.setPosition(0, degrees);
  // Set the Claw's timeout
  ClawMotor.setTimeout(2, seconds);
  // Open the Claw and hold the position for two seconds
  ClawMotor.spinFor(reverse, 60, degrees);
  wait(2, seconds);
  // Close the Claw slightly and hold that position for two seconds
  ClawMotor.spinFor(forward, 25, degrees);
  wait(2, seconds);
  // Return the claw to its original position
  ClawMotor.spinTo(0, degrees);
}
