/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*    This program will spin the servo to different positions.                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// ServoG               servo         G               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  ServoG.setPosition(-50, degrees);
  wait(1, seconds);
  ServoG.setPosition(-25, degrees);
  wait(1, seconds);
  ServoG.setPosition(0, degrees);
  wait(1, seconds);
  ServoG.setPosition(25, degrees);
  wait(1, seconds);
  ServoG.setPosition(50, degrees);
}
