/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Sun Oct 06 2019                                           */
/*    Description:  Functions (No Returns)                                    */
/*                  This program uses a function to print text on the next    */
/*                  avaiable row on the Brain's Screen.                       */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// printOnNewLine function takes a character pointer as an argument. This is one
// way that will allow you to pass string values. The function will take the
// string, and print it on the next available row on the Brain's Screen. If there
// are no rows available, the Screen will clear and reset.
void printOnNewLine(const char *message) {

  if (Brain.Screen.row() == 12) {
    // The Brain is on it's last row. Clear the Screen and reset the cursor.
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1, 1);
  } else if (Brain.Screen.column() > 1) {
    // Text has been already printed on this row. Move the cursor to the next
    // line.
    Brain.Screen.newLine();
  } else {
    // There is no message yet on this row. Do nothing...
  }

  // Print the message passed from the parameter.
  Brain.Screen.print(message);
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  // print on all 12 lines in 500 ms intervals.
  repeat(12) {
    printOnNewLine("New Line");
    wait(500, msec);
  }

  // wait 3 seconds before adding more text to the brain. The next
  // printOnNewLine function call will clear the screen.
  wait(3, seconds);
  printOnNewLine("This call will reset the screen.");
}
