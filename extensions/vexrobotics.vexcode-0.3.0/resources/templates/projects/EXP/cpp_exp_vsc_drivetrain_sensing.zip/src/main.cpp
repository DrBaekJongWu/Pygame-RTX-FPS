/*----------------------------------------------------------------------------------------*/
/*                                                                                        */
/*    Project:          Drivetrain Sensing                                                */
/*    Module:           main.cpp                                                          */
/*    Author:           VEX                                                               */
/*    Description:      This example will print Drivetrain-related                        */
/*                      information to the EXP Brain's Screen                             */
/*                                                                                        */
/*    Configuration:    EXP BaseBot (Drivetrain 2-motor, Inertial)                        */
/*                                                                                        */
/*----------------------------------------------------------------------------------------*/

// Include the VEX Library
#include "vex.h"

// Allows for easier use of the VEX Library
using namespace vex;

// Brain should be defined by default
brain Brain;

// Robot configuration code.
inertial BrainInertial = inertial();
motor LeftDriveSmart = motor(PORT6, false);
motor RightDriveSmart = motor(PORT10, true);
smartdrive Drivetrain = smartdrive(LeftDriveSmart, RightDriveSmart, BrainInertial, 259.34, 320, 40, mm, 1);


void calibrateDrivetrain() {
  wait(200, msec);
  Brain.Screen.print("Calibrating");
  Brain.Screen.newLine();
  Brain.Screen.print("Inertial");
  BrainInertial.calibrate();
  while (BrainInertial.isCalibrating()) {
    wait(25, msec);
  }

  // Clears the screen and returns the cursor to row 1, column 1.
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1, 1);
}

int main() {
  // Calibrates the Drivetrain Inertial
  calibrateDrivetrain();
  
  // Begin project code
  // Reset Rotation and Heading values
  Drivetrain.setHeading(0, degrees);
  Drivetrain.setRotation(0, degrees);

  // Change the font size to fit on the Brain's screen
  Brain.Screen.setFont(mono12);
  
  Drivetrain.drive(forward);

  // Print Drivetrain sensing values in a loop
  while (true) {
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1, 1);

    Brain.Screen.print("Velocity: %.0f rpm", Drivetrain.velocity(rpm));
    Brain.Screen.newLine();

    Brain.Screen.print("Current: %.3f amps", Drivetrain.current(amp));
    Brain.Screen.newLine();

    Brain.Screen.print("Rotation: %.0f degrees", Drivetrain.rotation(degrees));
    Brain.Screen.newLine();

    Brain.Screen.print("Heading: %.0f degrees", Drivetrain.heading(degrees));
    Brain.Screen.newLine(); 

    // A brief delay to allow text to be printed without distortion or tearing
    wait(200, msec);
  }
}